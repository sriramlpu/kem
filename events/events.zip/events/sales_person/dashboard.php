<?php
// KMK/events/sales_person/dashboard.php

session_start();

// --- REQUIRED GLOBAL TABLE DEFINITIONS ---
// These global variables must be defined BEFORE including functions.php
// because your functions.php relies on them for table names.
$clientsTable = 'clients'; 
$proposalItemsTable = 'proposal_items';

// Other tables needed by your functions.php for context (assuming placeholders for others)
// If you don't use these features, they might not be strictly needed, but included for completeness
$servTable = 'service'; 
$distTable = 'districts';
$docsTable = 'doctors_executives'; // Used in getExecutives*
$specTable = 'specialities';       // Used in getSpecialitiesByCategory
$cityTable = 'cities';             // Used in getAllCities*
$adminTable = 'admin_users';       // Used in getAdminDetails

// Constants assumed by your functions.php for pharma/issue tracking
define('TABLE_ISSUES', 'issues');
define('TABLE_REPLIES', 'issue_replies');
define('TABLE_STATUS', 'issue_status');
define('TABLE_ITEMS', 'items'); // Assuming this refers to menu items or proposal items


// --- INCLUDE CORRECTED PATH ---
// Correct path is two levels up to reach the KMK/ directory.
require_once('../../functions.php'); 

if (!isset($_SESSION['sales_person'])) {
    // A placeholder for the sales person, typically set during login
    $_SESSION['sales_person'] = 'Sales Representative';
}

// Global configuration (kept in the dashboard for easy viewing)
$status_config = [
    'LEAD_CREATED' => ['class' => 'bg-warning', 'text' => 'New Lead', 'icon' => 'bi-lightbulb'],
    'SALES_DRAFT' => ['class' => 'bg-warning', 'text' => 'Draft', 'icon' => 'bi-file-earmark-text'],
    'ADMIN_REVIEW' => ['class' => 'bg-info', 'text' => 'Admin Review', 'icon' => 'bi-clock-history'],
    'ADMIN_APPROVED' => ['class' => 'bg-success', 'text' => 'Admin Approved', 'icon' => 'bi-check-circle'],
    'EXECUTIVE_REVIEW' => ['class' => 'bg-primary', 'text' => 'Executive Review', 'icon' => 'bi-star'],
    'EXECUTIVE_APPROVED' => ['class' => 'bg-teal', 'text' => 'Completed', 'icon' => 'bi-check-all'],
    'REJECTED' => ['class' => 'bg-danger', 'text' => 'Rejected', 'icon' => 'bi-x-octagon']
];

$stat_card_colors = [
    'total_leads' => 'bg-primary',
    'draft_proposals' => 'bg-warning',
    'pending_admin' => 'bg-info',
    'admin_approved' => 'bg-success',
    'pending_executive' => 'bg-purple', // Custom class
    'completed' => 'bg-teal' // Custom class
];

$draft_status_key = 'LEAD_CREATED,SALES_DRAFT';


// --- Fetch Statistics using your functions ---
$stats = [
    'total_leads' => 0,
    'draft_proposals' => 0,
    'pending_admin' => 0,
    'admin_approved' => 0,
    'pending_executive' => 0,
    'completed' => 0
];

// Using your `exeSql` which is `getAllResults`
$sql_stats = "SELECT
    COUNT(*) as total_leads,
    SUM(CASE WHEN workflow_stage = 'LEAD_CREATED' OR workflow_stage = 'SALES_DRAFT' THEN 1 ELSE 0 END) as draft_proposals,
    SUM(CASE WHEN workflow_stage = 'ADMIN_REVIEW' THEN 1 ELSE 0 END) as pending_admin,
    SUM(CASE WHEN workflow_stage = 'ADMIN_APPROVED' THEN 1 ELSE 0 END) as admin_approved,
    SUM(CASE WHEN workflow_stage = 'EXECUTIVE_REVIEW' THEN 1 ELSE 0 END) as pending_executive,
    SUM(CASE WHEN workflow_stage = 'EXECUTIVE_APPROVED' THEN 1 ELSE 0 END) as completed
FROM $clientsTable";

$result_stats = exeSql($sql_stats); 

if (!empty($result_stats) && isset($result_stats[0])) {
    $stats = $result_stats[0];
}

// --- Fetch all clients using your functions ---
$clients = [];
$sql_clients = "SELECT c.*,
    (SELECT COUNT(*) FROM $proposalItemsTable WHERE client_id = c.client_id) as item_count
    FROM $clientsTable c
    ORDER BY c.created_at DESC";

$clients = exeSql($sql_clients); 
if (!$clients) {
    $clients = []; // Ensure $clients is an array if no results are returned
}

// --- Success Message Handling (simplified with local function, or just kept inline) ---
$success_message = '';
if (isset($_GET['success'])) {
    switch ($_GET['success']) {
        case 'sent_to_executive':
            $success_message = 'Proposal successfully sent to Executive Manager! The status is now **Executive Review**.';
            break;
        case 'menu_updated':
            $success_message = 'Menu items updated successfully! Status is **Sales Draft**.';
            break;
        case 'proposal_created':
            $success_message = 'Proposal created and saved as **Sales Draft**!'; 
            break;
        case 'client_deleted':
            $success_message = 'Client record successfully deleted.'; 
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Dashboard | KMK Catering</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        /* Define richer colors if not using default primary/secondary */
        .bg-purple {
            background-color: #6f42c1 !important; /* Bootstrap purple */
        }
        .bg-teal {
            background-color: #20c997 !important; /* Bootstrap teal */
        }

        body {
            /* Clean light background */
            background-color: #f8f9fa;
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-bottom: 50px;
        }

        .dashboard-container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .dashboard-header, .stat-card, .clients-table-card {
            background: white;
            border-radius: 10px; /* Slightly smaller radius for professional look */
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }

        .dashboard-header {
            padding: 25px;
            margin-bottom: 30px;
        }

        /* --- Stat Cards Styling --- */
        .stat-card {
            padding: 25px;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            height: 100%;
            cursor: pointer;
            border: 1px solid rgba(0,0,0,0.05);
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }

        .stat-icon {
            width: 50px; /* Reduced size */
            height: 50px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem; /* Reduced font size */
            margin-bottom: 10px;
            color: white !important;
        }

        .stat-number {
            font-size: 2rem; /* Reduced font size */
            font-weight: 700;
            line-height: 1.1;
            margin-bottom: 3px;
        }

        .stat-label {
            color: #6c757d; /* Bootstrap text-secondary */
            font-size: 0.9rem;
            font-weight: 500;
        }

        /* --- Main Content Styling --- */
        .clients-table-card {
            padding: 30px;
            margin-top: 30px;
        }

        .section-title {
            font-weight: 700;
            color: #212529; /* Bootstrap text-dark */
            margin-bottom: 25px;
            padding-bottom: 10px;
            /* Using standard Bootstrap primary color for underline */
            border-bottom: 3px solid var(--bs-primary);
            display: inline-block;
        }

        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
            white-space: nowrap;
        }

        .table-actions {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }

        .btn-action {
            padding: 4px 8px;
            font-size: 0.75rem;
            border-radius: 4px;
            white-space: nowrap;
        }

        /* --- Filter Tabs Styling --- */
        .filter-tabs {
            margin-bottom: 20px;
            border-bottom: 1px solid #e9ecef;
        }

        .filter-tabs .nav-link {
            color: #6c757d;
            font-weight: 600;
            border-radius: 8px 8px 0 0;
            padding: 8px 15px;
            margin-right: 5px;
            transition: all 0.2s;
            border-bottom: 3px solid transparent;
        }

        .filter-tabs .nav-link.active {
            background-color: var(--bs-primary);
            color: white;
            border-color: var(--bs-primary);
        }

        .filter-tabs .nav-link:not(.active):hover {
            color: var(--bs-primary);
        }
    </style>
</head>
<body>
    <div class="dashboard-container">

        <div class="dashboard-header">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center">
                <div>
                    <h1 class="mb-1"><i class="bi bi-speedometer2 text-primary"></i> Sales Dashboard</h1>
                    <p class="text-muted mb-0">Welcome back, **<?php echo htmlspecialchars($_SESSION['sales_person']); ?>**!</p>
                </div>
                <div class="mt-3 mt-md-0">
                    <a href="create_lead.php" class="btn btn-primary me-2">
                        <i class="bi bi-plus-circle"></i> New Lead
                    </a>
                    <a href="logout.php" class="btn btn-outline-danger">
                        <i class="bi bi-box-arrow-right"></i> Logout
                    </a>
                </div>
            </div>
        </div>

        <?php if ($success_message): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill"></i> **Success:** <?php echo $success_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <div class="row g-3 mb-4">

            <?php
            $stat_cards = [
                // Note: The data-filter attribute is the key the JS uses for filtering
                ['key' => 'total_leads', 'label' => 'Total Leads', 'icon' => 'bi-people', 'color' => $stat_card_colors['total_leads'], 'data_filter' => 'ALL'],
                ['key' => 'draft_proposals', 'label' => 'Draft / New', 'icon' => 'bi-file-earmark-text', 'color' => $stat_card_colors['draft_proposals'], 'data_filter' => $draft_status_key],
                ['key' => 'pending_admin', 'label' => 'Admin Review', 'icon' => 'bi-clock-history', 'color' => $stat_card_colors['pending_admin'], 'data_filter' => 'ADMIN_REVIEW'],
                ['key' => 'admin_approved', 'label' => 'Admin Approved', 'icon' => $status_config['ADMIN_APPROVED']['icon'], 'color' => $stat_card_colors['admin_approved'], 'data_filter' => 'ADMIN_APPROVED'],
                ['key' => 'pending_executive', 'label' => 'Executive Review', 'icon' => $status_config['EXECUTIVE_REVIEW']['icon'], 'color' => $stat_card_colors['pending_executive'], 'data_filter' => 'EXECUTIVE_REVIEW'],
                ['key' => 'completed', 'label' => 'Completed', 'icon' => $status_config['EXECUTIVE_APPROVED']['icon'], 'color' => $stat_card_colors['completed'], 'data_filter' => 'EXECUTIVE_APPROVED']
            ];

            foreach ($stat_cards as $card):
            ?>
            <div class="col-6 col-md-4 col-lg-2">
                <div class="stat-card" onclick="triggerFilter('<?php echo $card['data_filter']; ?>')">
                    <div class="stat-icon <?php echo $card['color']; ?>">
                        <i class="bi <?php echo $card['icon']; ?>"></i>
                    </div>
                    <div class="stat-number"><?php echo number_format($stats[$card['key']]); ?></div>
                    <div class="stat-label"><?php echo $card['label']; ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="clients-table-card">
            <h3 class="section-title"><i class="bi bi-table text-primary"></i> All Clients & Proposals</h3>

            <ul class="nav nav-pills filter-tabs" id="statusFilter" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link active" id="tab-ALL" href="#" data-filter="ALL" onclick="filterClientsByTab(event, 'ALL')" role="tab">All</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="tab-DRAFT" href="#" data-filter="<?php echo $draft_status_key; ?>" onclick="filterClientsByTab(event, '<?php echo $draft_status_key; ?>')" role="tab">New Leads & Drafts</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="tab-ADMIN_REVIEW" href="#" data-filter="ADMIN_REVIEW" onclick="filterClientsByTab(event, 'ADMIN_REVIEW')" role="tab">Admin Review</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="tab-ADMIN_APPROVED" href="#" data-filter="ADMIN_APPROVED" onclick="filterClientsByTab(event, 'ADMIN_APPROVED')" role="tab">Admin Approved</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="tab-EXECUTIVE_REVIEW" href="#" data-filter="EXECUTIVE_REVIEW" onclick="filterClientsByTab(event, 'EXECUTIVE_REVIEW')" role="tab">Executive Review</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="tab-EXECUTIVE_APPROVED" href="#" data-filter="EXECUTIVE_APPROVED" onclick="filterClientsByTab(event, 'EXECUTIVE_APPROVED')" role="tab">Completed</a>
                </li>
            </ul>

            <div class="table-responsive">
                <table class="table table-hover align-middle" id="clientsTable">
                    <thead class="table-light">
                        <tr>
                            <th>Client Name</th>
                            <th>Lead Status</th> 
                            <th>Contact</th>
                            <th>Event Date</th>
                            <th>Event Type</th>
                            <th>Status</th>
                            <th>Budget</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($clients) > 0): ?>
                            <?php
                            foreach ($clients as $client):
                                // Use array access instead of object access for $client
                                $workflow_stage = $client['workflow_stage'] ?? 'LEAD_CREATED'; 
                                $status = $status_config[$workflow_stage] ?? $status_config['LEAD_CREATED'];
                                
                                // Determine the filter group key for this client row.
                                $filter_group = in_array($workflow_stage, ['LEAD_CREATED', 'SALES_DRAFT']) ? $draft_status_key : $workflow_stage;
                                
                                // Check if a proposal (line items) has been created.
                                $has_proposal_items = ($client['item_count'] ?? 0) > 0;
                            ?>
                            <tr data-status="<?php echo htmlspecialchars($workflow_stage); ?>" data-filter-group="<?php echo $filter_group; ?>">
                                
                                <td>
                                    <strong><?php echo htmlspecialchars($client['client_name'] ?? 'N/A'); ?></strong>
                                </td>
                                <td>
                                    <span class="badge <?php echo (($client['lead_status'] ?? 'New') == 'New') ? 'bg-info' : 'bg-secondary'; ?>">
                                        <?php echo htmlspecialchars($client['lead_status'] ?? 'N/A'); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($client['contact_no'] ?? 'N/A'); ?></td>
                                <td>
                                    <?php 
                                    $event_date_time = $client['date_time_of_event'] ?? '';
                                    if ($event_date_time):
                                        echo date('M d, Y', strtotime($event_date_time)) . '<br>';
                                        echo '<small class="text-muted">' . date('h:i A', strtotime($event_date_time)) . '</small>';
                                    else:
                                        echo 'N/A';
                                    endif;
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars($client['event_type'] ?? 'N/A'); ?></td>
                                <td>
                                    <span class="status-badge <?php echo $status['class']; ?> text-white">
                                        <i class="bi <?php echo $status['icon']; ?> me-1"></i> <?php echo $status['text']; ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($client['budget_draft_sales'] ?? false): ?>
                                        <strong>₹<?php echo number_format($client['budget_draft_sales'], 2); ?></strong>
                                    <?php else: ?>
                                        <span class="text-muted">Not set</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="table-actions">
                                        <a href="view_proposal.php?client_id=<?php echo $client['client_id']; ?>"
                                            class="btn btn-sm btn-outline-primary btn-action"
                                            title="View Details">
                                            <i class="bi bi-eye"></i> View
                                        </a>

                                        <?php 
                                        $client_id = $client['client_id'];
                                        $show_propose_button = (
                                            $workflow_stage == 'LEAD_CREATED' || 
                                            ($workflow_stage == 'SALES_DRAFT' && !$has_proposal_items) ||
                                            $workflow_stage == 'REJECTED'
                                        );
                                        if ($show_propose_button): ?>
                                            <a href="prepare_proposal.php?client_id=<?php echo $client_id; ?>"
                                                class="btn btn-sm btn-primary btn-action"
                                                title="Prepare Proposal">
                                                <i class="bi bi-file-earmark-plus"></i> Propose
                                            </a>
                                        <?php endif; ?>

                                        <?php if ($workflow_stage == 'ADMIN_APPROVED'): ?>
                                            <a href="send_to_executive.php?client_id=<?php echo $client_id; ?>"
                                                class="btn btn-sm btn-success btn-action"
                                                title="Send to Executive">
                                                <i class="bi bi-send"></i> Send
                                            </a>
                                        <?php endif; ?>

                                        <?php 
                                        $show_menu_edit = $has_proposal_items && in_array($workflow_stage, ['SALES_DRAFT', 'ADMIN_REVIEW', 'REJECTED']);
                                        
                                        if ($show_menu_edit): 
                                        ?>
                                            <a href="edit_proposal_menu.php?client_id=<?php echo $client_id; ?>"
                                                class="btn btn-sm btn-outline-warning btn-action"
                                                title="Edit Menu">
                                                <i class="bi bi-list-check"></i> Menu
                                            </a>
                                        <?php endif; ?>

                                        <a href="client_sales_update.php?client_id=<?php echo $client_id; ?>"
                                            class="btn btn-sm btn-outline-secondary btn-action"
                                            title="Edit Details">
                                            <i class="bi bi-gear"></i> Edit
                                        </a>
                                        
                                        <?php 
                                        // Delete button for rejected or new leads
                                        if (in_array($workflow_stage, ['REJECTED', 'LEAD_CREATED'])): ?>
                                            <button class="btn btn-sm btn-danger btn-action"
                                                onclick="deleteClient(<?php echo $client_id; ?>)"
                                                title="Delete Client">
                                                <i class="bi bi-trash"></i> Delete
                                            </button>
                                        <?php endif; ?>
                                        
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr class="empty-data-row">
                                <td colspan="8" class="text-center py-5">
                                    <div class="empty-state">
                                        <i class="bi bi-inbox display-4 text-muted mb-3"></i>
                                        <h5>No clients found</h5>
                                        <p>Start by creating a new lead</p>
                                        <a href="create_lead.php" class="btn btn-primary">
                                            <i class="bi bi-plus-circle"></i> Create New Lead
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div id="noResults" class="alert alert-warning text-center mt-3" style="display:none;">
                <i class="bi bi-info-circle me-2"></i> No clients found for the selected status.
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const DRAFT_STATUS_KEY = '<?php echo $draft_status_key; ?>'; // LEAD_CREATED,SALES_DRAFT

        /**
         * Deletes a client record via AJAX.
         * NOTE: Assumes 'delete_client_api.php' is in the current directory and handles the deletion using your PHP functions.
         * @param {number} clientId - The ID of the client to delete.
         */
        function deleteClient(clientId) {
            if (!confirm(`Are you sure you want to permanently delete Client ID #${clientId}? This action cannot be undone.`)) {
                return;
            }

            const formData = new FormData();
            formData.append('client_id', clientId);

            // Fetch request is relative to the current file (dashboard.php)
            fetch('delete_client_api.php', { 
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Success, reload the page with a success message
                    window.location.href = 'dashboard.php?success=client_deleted';
                } else {
                    alert('Error deleting client: ' + (data.error || 'Unknown API error.'));
                }
            })
            .catch(error => {
                console.error('Fetch error:', error);
                alert('Network error while attempting to delete the client.');
            });
        }
        
        /**
         * Core Filtering Logic: Shows/Hides table rows based on status group.
         * @param {string} statusGroup - The key to filter by (e.g., 'ALL', 'ADMIN_REVIEW', or 'LEAD_CREATED,SALES_DRAFT').
         */
        function filterClients(statusGroup) {
            const rows = document.querySelectorAll('#clientsTable tbody tr:not(.empty-data-row)');
            const statusGroupList = statusGroup === 'ALL' ? [] : statusGroup.split(',');
            let visibleRowCount = 0;

            rows.forEach(row => {
                const rowStatus = row.getAttribute('data-status');

                let shouldDisplay = false;

                if (statusGroup === 'ALL') {
                    shouldDisplay = true;
                } else if (statusGroup === DRAFT_STATUS_KEY) {
                    // Check against the combined statuses for the DRAFT tab/card
                    if (rowStatus === 'LEAD_CREATED' || rowStatus === 'SALES_DRAFT') {
                        shouldDisplay = true;
                    }
                } else if (rowStatus === statusGroup) {
                    // Check against single status keys (e.g., ADMIN_REVIEW)
                    shouldDisplay = true;
                }

                row.style.display = shouldDisplay ? '' : 'none';
                if (shouldDisplay) {
                    visibleRowCount++;
                }
            });

            // Handle 'No Results' message visibility
            const noResultsDiv = document.getElementById('noResults');
            noResultsDiv.style.display = visibleRowCount === 0 ? '' : 'none';

            // Hide the 'No clients found' row from the PHP block if data exists
            const emptyDataRow = document.querySelector('.empty-data-row');
            if (emptyDataRow) {
                emptyDataRow.style.display = 'none';
            }
        }

        /**
         * Handles the click event for the filter tabs.
         * @param {Event} event - The click event.
         * @param {string} statusGroup - The key to filter by.
         */
        function filterClientsByTab(event, statusGroup) {
            event.preventDefault();

            // 1. Update active tab styling
            document.querySelectorAll('.filter-tabs .nav-link').forEach(link => {
                link.classList.remove('active');
            });
            event.target.classList.add('active');

            // 2. Filter table
            filterClients(statusGroup);
        }

        /**
         * Handles the click event for the Stat Cards (Triggers tab filter).
         * @param {string} statusGroup - The key to filter by (matches data-filter on the card).
         */
        function triggerFilter(statusGroup) {
            let targetTabId = '';

            if (statusGroup === DRAFT_STATUS_KEY) {
                targetTabId = 'tab-DRAFT';
            } else if (statusGroup === 'ALL') {
                targetTabId = 'tab-ALL';
            } else {
                targetTabId = 'tab-' + statusGroup;
            }

            const targetTab = document.getElementById(targetTabId);

            if (targetTab) {
                // Manually call the filter function to update table and styles
                filterClientsByTab({ preventDefault: () => {} , target: targetTab }, statusGroup);
            } else {
                // Fallback, though all stat cards should map to a tab
                filterClients(statusGroup);
            }
        }

        // --- Initial Load & Alert Handling ---
        document.addEventListener('DOMContentLoaded', () => {
            // 1. Ensure the 'All' tab is active and the table is filtered on load
            triggerFilter('ALL');

            // 2. Auto-hide success message after 5 seconds
            const alert = document.querySelector('.alert-success');
            if (alert) {
                // Use a proper Bootstrap instance if available
                if (typeof bootstrap !== 'undefined' && bootstrap.Alert) {
                     setTimeout(() => {
                         const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
                         bsAlert.close();
                     }, 5000);
                }
            }
        });
    </script>
</body>
</html>