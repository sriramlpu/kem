<?php
session_start();
// -------------------- DATABASE CONNECTION --------------------
$servername = "localhost";
$username   = "kmkglobal_web";
$password   = "tI]rfPhdOo9zHdKw";
$dbname     = "kmkglobal_web";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// -------------------- FETCH PROPOSALS --------------------
$filter = $_GET['filter'] ?? 'PENDING';
$allowed_filters = ['PENDING', 'APPROVED', 'REJECTED', 'ALL'];

if (!in_array($filter, $allowed_filters)) {
    $filter = 'PENDING';
}

$sql = "SELECT 
    client_id, client_name, contact_no, lead_status, 
    date_time_of_event, event_type, expected_budget, 
    budget_draft_sales, sales_notes, admin_status,
    services_required, food_category, decor_type,
    workflow_stage, admin_approved_by, admin_approved_at,
    admin_notes
FROM clients ";

// Start WHERE clause: Only select proposals that have been submitted (not just drafts or new leads).
// A submitted proposal must be in ADMIN_REVIEW, ADMIN_APPROVED, EXECUTIVE_REVIEW, EXECUTIVE_APPROVED, or REJECTED.
$sql .= "WHERE workflow_stage NOT IN ('LEAD_CREATED', 'SALES_DRAFT') ";

$params = [];
$types = "";

if ($filter !== 'ALL') {
    // Filter by the specific admin_status requested (PENDING, APPROVED, REJECTED)
    $sql .= "AND admin_status = ? ";
    $params[] = &$filter;
    $types .= "s";
}

$sql .= "ORDER BY 
    CASE 
        WHEN admin_status = 'PENDING' THEN 1
        WHEN admin_status = 'APPROVED' THEN 2
        WHEN admin_status = 'REJECTED' THEN 3
        ELSE 4
    END,
    date_time_of_event DESC";

$stmt = $conn->prepare($sql);

if ($filter !== 'ALL') {
    $stmt->bind_param($types, $filter);
}

$stmt->execute();
$result = $stmt->get_result();

$proposals = [];
while ($row = $result->fetch_assoc()) {
    $proposals[] = $row;
}

$stmt->close();

// -------------------- COUNT STATISTICS --------------------
// The counts must now reflect proposals that have passed the submission threshold.
$sql_stats = "SELECT 
    COUNT(CASE WHEN admin_status = 'PENDING' AND workflow_stage = 'ADMIN_REVIEW' THEN 1 END) as pending_count,
    COUNT(CASE WHEN admin_status = 'APPROVED' AND workflow_stage IN ('ADMIN_APPROVED', 'EXECUTIVE_REVIEW', 'EXECUTIVE_APPROVED') THEN 1 END) as approved_count,
    COUNT(CASE WHEN admin_status = 'REJECTED' AND workflow_stage = 'REJECTED' THEN 1 END) as rejected_count,
    COUNT(CASE WHEN workflow_stage NOT IN ('LEAD_CREATED', 'SALES_DRAFT') THEN 1 END) as total_count
FROM clients";

$result_stats = $conn->query($sql_stats);
$stats = $result_stats->fetch_assoc();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Approval Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #3498db;
            --success-color: #27ae60;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
        }
        
        .bg-purple {
            background-color: #6f42c1 !important;
        }
        .bg-teal {
            background-color: #20c997 !important;
        }
        
        body {
            background-color: #f8f9fa;
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding: 20px 0;
        }
        .dashboard-container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .dashboard-header {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            padding: 25px;
            margin-bottom: 30px;
        }
        .dashboard-header h1 {
            font-size: 2rem;
            font-weight: 700;
            margin: 0;
            color: #212529;
        }
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            text-align: left;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            cursor: pointer;
            border: 1px solid rgba(0,0,0,0.05);
        }
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: white !important;
        }
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            line-height: 1.1;
            margin-bottom: 3px;
            color: #212529;
        }
        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
            font-weight: 500;
        }
        .stat-card.pending .stat-icon { background-color: var(--warning-color); }
        .stat-card.approved .stat-icon { background-color: var(--success-color); }
        .stat-card.rejected .stat-icon { background-color: var(--danger-color); }
        .stat-card.total .stat-icon { background-color: var(--primary-color); }
        .filter-tabs {
            padding: 0;
            margin-bottom: 20px;
            border-bottom: 1px solid #e9ecef;
        }
        .filter-tabs .nav-link {
            color: #6c757d;
            font-weight: 600;
            border-radius: 8px 8px 0 0;
            padding: 10px 20px;
            margin-right: 5px;
            transition: all 0.2s;
            border: none;
            border-bottom: 3px solid transparent;
        }
        .filter-tabs .nav-link.active {
            background-color: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        .filter-tabs .nav-link:not(.active):hover {
            color: var(--primary-color);
            background-color: #f8f9fa;
        }
        .proposals-section {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            padding: 30px;
        }
        .section-title {
            font-weight: 700;
            color: #212529;
            margin-bottom: 25px;
            padding-bottom: 10px;
            border-bottom: 3px solid var(--primary-color);
            display: inline-block;
        }
        .proposal-card {
            background: white;
            border: 2px solid #dee2e6;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            transition: all 0.3s;
        }
        .proposal-card:hover {
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            transform: translateX(5px);
        }
        .proposal-card.pending { border-left: 5px solid var(--warning-color); }
        .proposal-card.approved { border-left: 5px solid var(--success-color); }
        .proposal-card.rejected { border-left: 5px solid var(--danger-color); }
        .badge-status {
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .badge-pending { background: #fff3cd; color: #856404; }
        .badge-approved { background: #d4edda; color: #155724; }
        .badge-rejected { background: #f8d7da; color: #721c24; }
        .action-buttons .btn {
            margin: 0 5px;
            border-radius: 25px;
            font-weight: 600;
            padding: 8px 20px;
        }
        .proposal-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .detail-item {
            background: #f8f9fa;
            padding: 12px;
            border-radius: 8px;
        }
        .detail-item label {
            font-weight: 600;
            color: #495057;
            font-size: 0.85rem;
            display: block;
            margin-bottom: 5px;
        }
        .detail-item .value {
            color: #212529;
            font-size: 1rem;
        }
        #message-box {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1050;
            max-width: 400px;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }
        .empty-state svg {
            width: 100px;
            height: 100px;
            margin-bottom: 20px;
            opacity: 0.5;
        }
        .notes-section {
            background: #e7f3ff;
            border-left: 4px solid #0d6efd;
            padding: 15px;
            margin-top: 15px;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<div id="message-box"></div>

<div class="dashboard-container">
    <div class="dashboard-header">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center">
            <div>
                <h1><i class="bi bi-clipboard-check text-primary me-2"></i>Admin Approval Dashboard</h1>
                <p class="text-muted mb-0">Review and manage sales proposals</p>
            </div>
            <div class="mt-3 mt-md-0">
                <a href="sales_dashboard.php" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i>Back to Sales
                </a>
            </div>
        </div>
    </div>

    <div class="stats-cards">
        <div class="stat-card pending" onclick="filterByStatus('PENDING')">
            <div class="stat-icon">
                <i class="bi bi-clock-history"></i>
            </div>
            <div class="stat-number"><?php echo $stats['pending_count']; ?></div>
            <div class="stat-label">Pending Review</div>
        </div>
        <div class="stat-card approved" onclick="filterByStatus('APPROVED')">
            <div class="stat-icon">
                <i class="bi bi-check-circle"></i>
            </div>
            <div class="stat-number"><?php echo $stats['approved_count']; ?></div>
            <div class="stat-label">Approved</div>
        </div>
        <div class="stat-card rejected" onclick="filterByStatus('REJECTED')">
            <div class="stat-icon">
                <i class="bi bi-x-circle"></i>
            </div>
            <div class="stat-number"><?php echo $stats['rejected_count']; ?></div>
            <div class="stat-label">Rejected</div>
        </div>
        <div class="stat-card total" onclick="filterByStatus('ALL')">
            <div class="stat-icon">
                <i class="bi bi-list-ul"></i>
            </div>
            <div class="stat-number"><?php echo $stats['total_count']; ?></div>
            <div class="stat-label">Total Submissions</div>
        </div>
    </div>

    <div class="proposals-section">
        <h3 class="section-title"><i class="bi bi-table text-primary me-2"></i>All Submissions for Admin Review</h3>
        
        <ul class="nav nav-pills filter-tabs" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link <?php echo $filter === 'PENDING' ? 'active' : ''; ?>" 
                   href="#" data-filter="PENDING" onclick="filterProposals(event, 'PENDING')">
                    <i class="bi bi-clock-history me-1"></i>Pending (<?php echo $stats['pending_count']; ?>)
                </a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link <?php echo $filter === 'APPROVED' ? 'active' : ''; ?>" 
                   href="#" data-filter="APPROVED" onclick="filterProposals(event, 'APPROVED')">
                    <i class="bi bi-check-circle me-1"></i>Approved (<?php echo $stats['approved_count']; ?>)
                </a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link <?php echo $filter === 'REJECTED' ? 'active' : ''; ?>" 
                   href="#" data-filter="REJECTED" onclick="filterProposals(event, 'REJECTED')">
                    <i class="bi bi-x-circle me-1"></i>Rejected (<?php echo $stats['rejected_count']; ?>)
                </a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link <?php echo $filter === 'ALL' ? 'active' : ''; ?>" 
                   href="#" data-filter="ALL" onclick="filterProposals(event, 'ALL')">
                    <i class="bi bi-list-ul me-1"></i>All (<?php echo $stats['total_count']; ?>)
                </a>
            </li>
        </ul>

        <div id="proposalsContainer">
        <?php if (empty($proposals)): ?>
            <div class="empty-state">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <h3>No proposals requiring action found</h3>
                <p>There are no proposals actively pending or previously managed by the admin role at the moment. (Filter is based on submissions past the draft stage)</p>
            </div>
        <?php else: ?>
            <?php foreach ($proposals as $proposal): ?>
                <?php 
                    $status_class = strtolower($proposal['admin_status'] ?? 'pending');
                    $badge_class = 'badge-' . $status_class;
                ?>
                <div class="proposal-card <?php echo $status_class; ?>" 
                     id="proposal-<?php echo $proposal['client_id']; ?>"
                     data-status="<?php echo $proposal['admin_status'] ?? 'PENDING'; ?>">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <h4 class="mb-1"><?php echo htmlspecialchars($proposal['client_name']); ?></h4>
                            <span class="text-muted">Client ID: <?php echo $proposal['client_id']; ?></span>
                        </div>
                        <span class="badge-status <?php echo $badge_class; ?>">
                            <?php echo strtoupper($proposal['admin_status'] ?? 'PENDING'); ?>
                        </span>
                    </div>

                    <div class="proposal-details">
                        <div class="detail-item">
                            <label><i class="bi bi-calendar-event me-1"></i>Event Type</label>
                            <div class="value"><?php echo htmlspecialchars($proposal['event_type'] ?? 'N/A'); ?></div>
                        </div>
                        <div class="detail-item">
                            <label><i class="bi bi-calendar-date me-1"></i>Event Date</label>
                            <div class="value"><?php echo date('M d, Y', strtotime($proposal['date_time_of_event'])); ?></div>
                        </div>
                        <div class="detail-item">
                            <label><i class="bi bi-telephone me-1"></i>Contact Number</label>
                            <div class="value"><?php echo htmlspecialchars($proposal['contact_no']); ?></div>
                        </div>
                        <div class="detail-item">
                            <label><i class="bi bi-star me-1"></i>Lead Status</label>
                            <div class="value"><?php echo htmlspecialchars($proposal['lead_status']); ?></div>
                        </div>
                        <div class="detail-item">
                            <label><i class="bi bi-gear me-1"></i>Services Required</label>
                            <div class="value"><?php echo htmlspecialchars($proposal['services_required'] ?? 'N/A'); ?></div>
                        </div>
                        <div class="detail-item">
                            <label><i class="bi bi-basket me-1"></i>Food Category</label>
                            <div class="value"><?php echo htmlspecialchars($proposal['food_category'] ?? 'N/A'); ?></div>
                        </div>
                        <div class="detail-item">
                            <label><i class="bi bi-palette me-1"></i>Decor Type</label>
                            <div class="value"><?php echo htmlspecialchars($proposal['decor_type'] ?? 'N/A'); ?></div>
                        </div>
                        <div class="detail-item">
                            <label><i class="bi bi-cash-stack me-1"></i>Expected Budget</label>
                            <div class="value"><?php echo htmlspecialchars($proposal['expected_budget'] ?? 'N/A'); ?></div>
                        </div>
                        <div class="detail-item">
                            <label><i class="bi bi-currency-rupee me-1"></i><strong>Proposed Budget</strong></label>
                            <div class="value"><strong>₹<?php echo number_format($proposal['budget_draft_sales'], 2); ?></strong></div>
                        </div>
                    </div>

                    <?php if (!empty($proposal['sales_notes'])): ?>
                        <div class="notes-section">
                            <strong><i class="bi bi-journal-text me-1"></i>Sales Notes:</strong><br>
                            <?php echo nl2br(htmlspecialchars($proposal['sales_notes'])); ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($proposal['admin_notes']) && $proposal['admin_status'] !== 'PENDING'): ?>
                        <div class="alert alert-secondary mt-3">
                            <strong><i class="bi bi-person-badge me-1"></i>Admin Notes:</strong><br>
                            <?php echo nl2br(htmlspecialchars($proposal['admin_notes'])); ?>
                            <?php if ($proposal['admin_approved_by']): ?>
                                <br><small class="text-muted">By: <?php echo htmlspecialchars($proposal['admin_approved_by']); ?> 
                                on <?php echo date('M d, Y H:i', strtotime($proposal['admin_approved_at'])); ?></small>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <div class="action-buttons text-end mt-3">
                        <a href="view_proposal.php?client_id=<?php echo $proposal['client_id']; ?>" 
                           class="btn btn-sm btn-info" target="_blank">
                            <i class="bi bi-eye me-1"></i>View Details
                        </a>
                        
                        <?php if ($proposal['admin_status'] === 'PENDING' || !$proposal['admin_status']): ?>
                            <button class="btn btn-sm btn-success" onclick="openApprovalModal(<?php echo $proposal['client_id']; ?>, 'APPROVED')">
                                <i class="bi bi-check-circle me-1"></i>Approve
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="openApprovalModal(<?php echo $proposal['client_id']; ?>, 'REJECTED')">
                                <i class="bi bi-x-circle me-1"></i>Reject
                            </button>
                        <?php elseif ($proposal['admin_status'] === 'APPROVED'): ?>
                            <button class="btn btn-sm btn-warning" onclick="updateStatus(<?php echo $proposal['client_id']; ?>, 'PENDING', '')">
                                <i class="bi bi-arrow-clockwise me-1"></i>Move to Pending
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="openApprovalModal(<?php echo $proposal['client_id']; ?>, 'REJECTED')">
                                <i class="bi bi-x-circle me-1"></i>Reject
                            </button>
                        <?php elseif ($proposal['admin_status'] === 'REJECTED'): ?>
                            <button class="btn btn-sm btn-success" onclick="openApprovalModal(<?php echo $proposal['client_id']; ?>, 'APPROVED')">
                                <i class="bi bi-check-circle me-1"></i>Approve
                            </button>
                            <button class="btn btn-sm btn-warning" onclick="updateStatus(<?php echo $proposal['client_id']; ?>, 'PENDING', '')">
                                <i class="bi bi-arrow-clockwise me-1"></i>Move to Pending
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div id="noResults" class="alert alert-warning text-center mt-3" style="display:none;">
        <i class="bi bi-info-circle me-2"></i>No proposals found for the selected status.
    </div>
</div>

    <div class="text-center p-4">
        <a href="sales_dashboard.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Back to Sales Dashboard
        </a>
    </div>
</div>

<div class="modal fade" id="approvalModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Notes (Optional)</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="modal-client-id">
                <input type="hidden" id="modal-status">
                <div class="mb-3">
                    <label class="form-label">Notes:</label>
                    <textarea class="form-control" id="modal-notes" rows="4" 
                              placeholder="Add any comments or reasons for this decision..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="submitApproval()">Confirm</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
let approvalModal;
const currentFilter = '<?php echo $filter; ?>';

document.addEventListener('DOMContentLoaded', function() {
    approvalModal = new bootstrap.Modal(document.getElementById('approvalModal'));
    
    // Apply initial filter
    if (currentFilter !== 'ALL') {
        applyFilter(currentFilter);
    }
});

function filterByStatus(status) {
    // Update URL and reload
    window.location.href = '?filter=' + status;
}

function filterProposals(event, status) {
    event.preventDefault();
    
    // Update active tab
    document.querySelectorAll('.filter-tabs .nav-link').forEach(link => {
        link.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Update URL and reload
    window.location.href = '?filter=' + status;
}

function applyFilter(status) {
    // NOTE: This client-side function remains for compatibility but is less critical 
    // since the PHP query already filters the data.
    const proposals = document.querySelectorAll('.proposal-card');
    let visibleCount = 0;
    
    proposals.forEach(proposal => {
        const proposalStatus = proposal.getAttribute('data-status');
        
        if (status === 'ALL' || proposalStatus === status) {
            proposal.style.display = 'block';
            visibleCount++;
        } else {
            proposal.style.display = 'none';
        }
    });
    
    // Show/hide no results message
    const noResults = document.getElementById('noResults');
    const emptyState = document.querySelector('.empty-state');
    
    if (visibleCount === 0 && !emptyState) {
        noResults.style.display = 'block';
    } else {
        noResults.style.display = 'none';
    }
}

function openApprovalModal(clientId, newStatus) {
    document.getElementById('modal-client-id').value = clientId;
    document.getElementById('modal-status').value = newStatus;
    document.getElementById('modal-notes').value = '';
    approvalModal.show();
}

function submitApproval() {
    const clientId = document.getElementById('modal-client-id').value;
    const status = document.getElementById('modal-status').value;
    const notes = document.getElementById('modal-notes').value;
    
    approvalModal.hide();
    updateStatus(clientId, status, notes);
}

function updateStatus(clientId, newStatus, notes = '') {
    if (!notes && !confirm(`Are you sure you want to mark this proposal as ${newStatus}?`)) {
        return;
    }

    const msgBox = document.getElementById('message-box');
    
    const formData = new FormData();
    formData.append('client_id', clientId);
    formData.append('admin_status', newStatus);
    formData.append('admin_notes', notes);
    
    // The API is assumed to handle the workflow_stage transition correctly.
    
    fetch('admin_approval_api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            msgBox.innerHTML = `<div class='alert alert-success alert-dismissible fade show'>
                <i class="bi bi-check-circle me-2"></i>${data.message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>`;
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            msgBox.innerHTML = `<div class='alert alert-danger alert-dismissible fade show'>
                <i class="bi bi-exclamation-triangle me-2"></i>Error: ${data.error}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>`;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        msgBox.innerHTML = `<div class='alert alert-danger alert-dismissible fade show'>
            <i class="bi bi-exclamation-triangle me-2"></i>Network Error: ${error.message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>`;
    });
}
</script>

</body>
</html>