<?php
// Redirect to the main dashboard file
header('Location: dashboard.php');
exit;
?>