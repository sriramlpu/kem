<?php
// Redirect to vendor totals page
header("Location: vendor.php");
exit();
?>
