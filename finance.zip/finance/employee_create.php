<?php
/**
 * FINANCE: Add New Employee
 */
require_once("../auth.php");
requireRole(['Admin', 'Finance']);
require_once("../functions.php");

include 'header.php';
include 'nav.php';
?>

<div class="container py-4" style="max-width: 900px;">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold m-0"><i class="bi bi-person-plus me-2 text-primary"></i>Add New Employee</h3>
        <a href="employees.php" class="btn btn-light border rounded-pill px-4 fw-bold">Cancel</a>
    </div>

    <div id="msgBox" class="mb-3"></div>

    <div class="card shadow-sm">
        <div class="card-body p-4">
            <form id="empForm">
                <!-- Personal Info -->
                <h6 class="fw-bold text-muted text-uppercase small mb-4 border-bottom pb-2">1. Personal Information</h6>
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Employee Name *</label>
                        <input type="text" name="employee_name" class="form-control" placeholder="Full Name" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Mobile Number</label>
                        <input type="text" name="mobile_number" class="form-control" placeholder="+91">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Email Address</label>
                        <input type="email" name="email" class="form-control" placeholder="name@kmkglobal.com">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Branch</label>
                        <select name="branch_id" id="branch_id" class="form-select select2" required>
                            <option value="">-- Select Branch --</option>
                        </select>
                    </div>
                </div>

                <!-- Salary Configuration -->
                <h6 class="fw-bold text-muted text-uppercase small mb-4 border-bottom pb-2">2. Payroll & Salary Details</h6>
                <div class="row g-3 mb-4">
                    <div class="col-md-4">
                        <label class="form-label fw-bold small">Gross Monthly Salary *</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light">₹</span>
                            <input type="number" name="salary" class="form-control fw-bold" placeholder="0.00" required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold small">Designation / Role</label>
                        <input type="text" name="role" class="form-control" placeholder="e.g. Accountant">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold small">Professional Tax</label>
                        <input type="number" name="professional_tax" class="form-control" value="0">
                    </div>
                </div>
                
                <div class="row g-3 mb-4 p-3 bg-light rounded-4 border border-primary-subtle">
                    <div class="col-md-4">
                        <label class="form-label small fw-bold">Basic Pay</label>
                        <input type="number" name="basic_pay" class="form-control" value="0">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold">HRA</label>
                        <input type="number" name="hra" class="form-control" value="0">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold">DA</label>
                        <input type="number" name="da" class="form-control" value="0">
                    </div>
                </div>

                <!-- Bank Info -->
                <h6 class="fw-bold text-muted text-uppercase small mb-4 border-bottom pb-2">3. Disbursement (Bank) Info</h6>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Bank Name</label>
                        <input type="text" name="bank_name" class="form-control" placeholder="e.g. HDFC Bank">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">IFSC Code</label>
                        <input type="text" name="ifsc_code" class="form-control" placeholder="e.g. HDFC0001234">
                    </div>
                </div>

                <div class="mt-5">
                    <button type="submit" class="btn btn-primary btn-lg w-100 rounded-pill shadow">
                        <i class="bi bi-shield-check me-2"></i> Register Employee & Generate UID
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(async function() {
    $('.select2').select2({ theme: 'bootstrap4' });

    // Load Branches
    const res = await fetch('api/employee_api.php?action=getBranches');
    const j = await res.json();
    if (j.status === 'success') {
        j.branches.forEach(b => $('#branch_id').append(new Option(b.branch_name, b.branch_id)));
    }

    $('#empForm').on('submit', async function(e) {
        e.preventDefault();
        const fd = new FormData(this);
        fd.append('action', 'create');
        
        try {
            const res = await fetch('api/employee_api.php', { method: 'POST', body: fd });
            const j = await res.json();
            if (j.status === 'success') {
                $('#msgBox').html('<div class="alert alert-success fw-bold rounded-4 shadow-sm">Created! UID: '+j.employee_uid+'</div>');
                setTimeout(() => window.location.href = 'employees.php', 1500);
            } else {
                $('#msgBox').html('<div class="alert alert-danger fw-bold rounded-4 shadow-sm">'+j.message+'</div>');
            }
        } catch(err) {
            $('#msgBox').html('<div class="alert alert-danger fw-bold">Network Error</div>');
        }
    });
});
</script>

<?php include 'footer.php'; ?>