<?php
/**
 * FINANCE: Edit Employee (Integrated with PF/ESI Calculator)
 * Path: finance/employee_edit.php
 */
require_once("../auth.php");
requireRole(['Admin', 'Finance']);
require_once("../functions.php");

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header("Location: employees.php"); exit; }

include 'header.php';
include 'nav.php';
?>

<div class="container py-4" style="max-width: 1000px;">
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
        <div>
            <h2 class="fw-bold h4 mb-0 text-dark">Modify Employee Profile</h2>
            <p class="text-muted small mb-0">Update master data, salary structure, and statutory percentages.</p>
        </div>
        <a href="employees.php" class="btn btn-outline-secondary rounded-pill px-4 fw-bold shadow-sm">Cancel</a>
    </div>

    <div id="msgBox"></div>

    <form id="editForm">
        <input type="hidden" name="id" value="<?= $id ?>">
        
        <div class="row g-4">
            <!-- Part 1: Identity -->
            <div class="col-md-12">
                <div class="card shadow-sm border-0 rounded-4 overflow-hidden">
                    <div class="card-body p-4">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label small fw-bold text-muted">EMPLOYEE NAME</label>
                                <input type="text" name="employee_name" id="e_name" class="form-control border-2" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold text-muted">EMPLOYEE UID (Readonly)</label>
                                <input type="text" id="e_uid" class="form-control bg-light border-0 fw-bold text-primary" readonly>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold text-muted">DESIGNATION</label>
                                <input type="text" name="role" id="e_role" class="form-control">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold text-muted">MOBILE</label>
                                <input type="text" name="mobile_number" id="e_mobile" class="form-control">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold text-muted">EMAIL</label>
                                <input type="email" name="email" id="e_email" class="form-control">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold text-muted">BRANCH</label>
                                <select name="branch_id" id="e_branch" class="form-select border-2"></select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Part 2: Payout Math -->
            <div class="col-md-7">
                <div class="card shadow-sm border-0 rounded-4 overflow-hidden h-100">
                    <div class="card-header bg-primary text-white py-3"><h6 class="mb-0 fw-bold small text-uppercase">Salary Components</h6></div>
                    <div class="card-body p-4">
                        <div class="row g-3 mb-4">
                            <div class="col-md-6">
                                <label class="form-label small fw-bold text-primary">GROSS SALARY (INR)</label>
                                <input type="number" name="salary" id="gross_salary" class="form-control form-control-lg fw-bold border-primary text-primary" step="0.01">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold text-muted">BASIC PAY</label>
                                <input type="number" name="basic_pay" id="basic_pay" class="form-control">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">HRA</label>
                                <input type="number" name="hra" id="hra" class="form-control">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">DA</label>
                                <input type="number" name="da" id="da" class="form-control">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">PROF. TAX</label>
                                <input type="number" name="professional_tax" id="pt_tax" class="form-control">
                            </div>
                        </div>

                        <div class="p-3 bg-light rounded-4 border">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">PF (%)</label>
                                    <input type="number" step="0.01" name="pf_percent" id="pf_percent" class="form-control">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">ESI (%)</label>
                                    <input type="number" step="0.01" name="esi_percent" id="esi_percent" class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Part 3: Preview & Bank -->
            <div class="col-md-5">
                <div class="card shadow border-0 rounded-4 overflow-hidden mb-4 bg-primary text-white">
                    <div class="card-body p-4">
                        <h6 class="fw-bold small text-uppercase opacity-75 mb-3">Live Payout Estimation</h6>
                        <div class="d-flex justify-content-between small mb-2"><span>PF:</span><span class="fw-bold">- ₹<span id="pf_val">0</span></span></div>
                        <div class="d-flex justify-content-between small mb-2"><span>ESI:</span><span class="fw-bold">- ₹<span id="esi_val">0</span></span></div>
                        <div class="d-flex justify-content-between small mb-3"><span>Tax:</span><span class="fw-bold">- ₹<span id="pt_val">0</span></span></div>
                        <div class="text-center pt-2 border-top border-white border-opacity-25">
                            <span class="d-block small text-uppercase opacity-75">Net Payable</span>
                            <div class="h2 fw-bold mb-0">₹<span id="net_val">0</span></div>
                        </div>
                    </div>
                </div>

                <div class="card shadow-sm border-0 rounded-4 overflow-hidden">
                    <div class="card-header bg-dark text-white py-3"><h6 class="mb-0 fw-bold small text-uppercase">Disbursement Info</h6></div>
                    <div class="card-body p-4">
                        <div class="mb-3">
                            <label class="form-label small fw-bold">BANK NAME</label>
                            <input type="text" name="bank_name" id="e_bank" class="form-control">
                        </div>
                        <div class="mb-0">
                            <label class="form-label small fw-bold">IFSC CODE</label>
                            <input type="text" name="ifsc_code" id="e_ifsc" class="form-control">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-5 text-center">
            <button type="submit" class="btn btn-primary btn-lg rounded-pill shadow px-5 py-3 fw-bold">
                <i class="bi bi-save2 me-2"></i> Update Employee Record
            </button>
        </div>
    </form>
</div>

<script>
$(document).ready(async function() {
    // 1. Load Branches
    const bRes = await fetch('api/employee_api.php?action=getBranches');
    const bj = await bRes.json();
    bj.branches.forEach(b => $('#e_branch').append(new Option(b.branch_name, b.branch_id)));

    // 2. Load Employee Data
    const eRes = await fetch('api/employee_api.php?action=getEmployee&id=<?= $id ?>');
    const ej = await eRes.json();
    if (ej.status === 'success') {
        const e = ej.employee;
        $('#e_name').val(e.employee_name);
        $('#e_uid').val(e.employee_uid);
        $('#e_mobile').val(e.mobile_number);
        $('#e_email').val(e.email);
        $('#e_role').val(e.role);
        $('#e_branch').val(e.branch_id);
        $('#gross_salary').val(e.salary);
        $('#basic_pay').val(e.basic_pay);
        $('#hra').val(e.hra);
        $('#da').val(e.da);
        $('#pf_percent').val(e.pf_percent);
        $('#esi_percent').val(e.esi_percent);
        $('#pt_tax').val(e.professional_tax);
        $('#e_bank').val(e.bank_name);
        $('#e_ifsc').val(e.ifsc_code);
        calculate();
    }

    /** CALCULATION ENGINE **/
    function calculate() {
        const gross = parseFloat($('#gross_salary').val() || 0);
        const basic = parseFloat($('#basic_pay').val() || 0);
        const da    = parseFloat($('#da').val() || 0);
        const pfPct = parseFloat($('#pf_percent').val() || 0);
        const esiPct= parseFloat($('#esi_percent').val() || 0);
        const pt    = parseFloat($('#pt_tax').val() || 0);

        const pf = Math.round((basic + da) * (pfPct / 100));
        const esi = (gross <= 21000) ? Math.ceil(gross * (esiPct / 100)) : 0;
        const net = Math.max(0, gross - pf - esi - pt);

        $('#pf_val').text(pf.toLocaleString());
        $('#esi_val').text(esi.toLocaleString());
        $('#pt_val').text(pt.toLocaleString());
        $('#net_val').text(net.toLocaleString('en-IN', {minimumFractionDigits: 2}));
    }

    $('#gross_salary, #basic_pay, #da, #pf_percent, #esi_percent, #pt_tax').on('input', calculate);

    // 3. Submit Update
    $('#editForm').on('submit', async function(e) {
        e.preventDefault();
        const fd = new FormData(this);
        fd.append('action', 'updateEmployee');
        
        const res = await fetch('api/employee_api.php', { method: 'POST', body: fd });
        const j = await res.json();
        if (j.status === 'success') {
            $('#msgBox').html('<div class="alert alert-success fw-bold rounded-4 shadow-sm mb-4">Record updated successfully!</div>');
            setTimeout(() => window.location.href = 'employees.php', 1200);
        }
    });
});
</script>

<?php include 'footer.php'; ?>