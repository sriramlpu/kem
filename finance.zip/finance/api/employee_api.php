<?php
/**
 * FINANCE API: Employee Management
 * Path: finance/api/employee_api.php
 * Handles CRUD and detailed payroll component calculation for the list view.
 */
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) session_start();

header('Content-Type: application/json; charset=UTF-8');
error_reporting(E_ALL & ~E_NOTICE);
ini_set('display_errors', '0');

// unauthorized check
if (!isset($_SESSION['userId'])) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Session expired.']);
    exit;
}

require_once("../../functions.php");

function json_out($data, int $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

$action = $_POST['action'] ?? ($_GET['action'] ?? '');

try {
    switch ($action) {
        case 'list':
            $branch_id = (int)($_GET['branch_id'] ?? 0);
            $yyyymm    = preg_replace('/\D/', '', (string)($_GET['yyyymm'] ?? date('Ym')));

            $where = ["e.status = 'Active'"];
            if ($branch_id > 0) $where[] = "e.branch_id = $branch_id";
            $where_sql = implode(' AND ', $where);

            /** * Optimized SQL:
             * Fetches individual sums for all payroll components for the specific month.
             */
            $sql = "SELECT e.*, b.branch_name,
                    (SELECT COALESCE(SUM(amount), 0) FROM employee_salary_payments WHERE employee_id = e.id AND pay_period = '$yyyymm') as paid_this_month,
                    (SELECT COALESCE(SUM(lop_amount), 0) FROM employee_salary_payments WHERE employee_id = e.id AND pay_period = '$yyyymm') as month_lop,
                    (SELECT COALESCE(SUM(ot_amount), 0) FROM employee_salary_payments WHERE employee_id = e.id AND pay_period = '$yyyymm') as month_ot,
                    (SELECT COALESCE(SUM(incentives), 0) FROM employee_salary_payments WHERE employee_id = e.id AND pay_period = '$yyyymm') as month_inc,
                    (SELECT COALESCE(SUM(pf_deduction), 0) FROM employee_salary_payments WHERE employee_id = e.id AND pay_period = '$yyyymm') as month_pf,
                    (SELECT COALESCE(SUM(esi_deduction), 0) FROM employee_salary_payments WHERE employee_id = e.id AND pay_period = '$yyyymm') as month_esi
                    FROM employees e
                    LEFT JOIN branches b ON b.branch_id = e.branch_id
                    WHERE $where_sql 
                    ORDER BY e.employee_name ASC";
            
            $rows = exeSql($sql) ?: [];
            $data = [];
            foreach($rows as $r) {
                $gross   = (float)($r['salary'] ?? 0);
                $paid    = (float)($r['paid_this_month'] ?? 0);
                
                $data[] = [
                    'id'            => (int)$r['id'],
                    'employee_uid'  => (string)$r['employee_uid'],
                    'employee_name' => (string)$r['employee_name'],
                    'role'          => (string)($r['role'] ?: 'Staff'),
                    'branch_name'   => (string)($r['branch_name'] ?: 'N/A'),
                    'salary'        => $gross,
                    'lop'           => (float)$r['month_lop'],
                    'ot'            => (float)$r['month_ot'],
                    'inc'           => (float)$r['month_inc'],
                    'pf'            => (float)$r['month_pf'],
                    'esi'           => (float)$r['month_esi'],
                    'advance'       => (float)($r['advance'] ?? 0),
                    'paid'          => $paid,
                    'balance'       => $gross - $paid,
                    'mobile'        => (string)$r['mobile_number']
                ];
            }
            json_out(['data' => $data]);
            break;

        case 'getEmployee':
            $id = (int)($_GET['id'] ?? 0);
            $res = exeSql("SELECT * FROM employees WHERE id = $id LIMIT 1");
            if (!$res) throw new Exception("Employee not found.");
            json_out(['status' => 'success', 'employee' => $res[0]]);
            break;

        case 'create':
            $name = trim((string)$_POST['employee_name']);
            if (!$name) throw new Exception("Name is required.");
            $uid = 'EMP' . date('ymd') . rand(100, 999);
            
            $data = [
                'employee_name'    => $name,
                'employee_uid'     => $uid,
                'mobile_number'    => trim((string)$_POST['mobile_number']),
                'email'            => trim((string)$_POST['email']),
                'role'             => trim((string)$_POST['role']),
                'branch_id'        => (int)$_POST['branch_id'] ?: null,
                'salary'           => (float)$_POST['salary'],
                'basic_pay'        => (float)$_POST['basic_pay'],
                'hra'              => (float)$_POST['hra'],
                'da'               => (float)$_POST['da'],
                'pf_percent'       => (float)($_POST['pf_percent'] ?? 12.00),
                'esi_percent'      => (float)($_POST['esi_percent'] ?? 0.75),
                'professional_tax' => (float)$_POST['professional_tax'],
                'bank_name'        => trim((string)$_POST['bank_name']),
                'ifsc_code'        => trim((string)$_POST['ifsc_code']),
                'status'           => 'Active'
            ];
            $newId = insData('employees', $data);
            json_out(['status' => 'success', 'id' => $newId, 'employee_uid' => $uid]);
            break;

        case 'updateEmployee':
            $id = (int)$_POST['id'];
            $data = [
                'employee_name'    => trim((string)$_POST['employee_name']),
                'mobile_number'    => trim((string)$_POST['mobile_number']),
                'email'            => trim((string)$_POST['email']),
                'role'             => trim((string)$_POST['role']),
                'branch_id'        => (int)$_POST['branch_id'] ?: null,
                'salary'           => (float)$_POST['salary'],
                'basic_pay'        => (float)$_POST['basic_pay'],
                'hra'              => (float)$_POST['hra'],
                'da'               => (float)$_POST['da'],
                'pf_percent'       => (float)($_POST['pf_percent'] ?? 12.00),
                'esi_percent'      => (float)($_POST['esi_percent'] ?? 0.75),
                'professional_tax' => (float)$_POST['professional_tax'],
                'bank_name'        => trim((string)$_POST['bank_name']),
                'ifsc_code'        => trim((string)$_POST['ifsc_code'])
            ];
            upData('employees', $data, ["id = $id"]);
            json_out(['status' => 'success']);
            break;

        case 'getBranches':
            $res = exeSql("SELECT branch_id, branch_name FROM branches ORDER BY branch_name ASC");
            json_out(['status' => 'success', 'branches' => $res ?: []]);
            break;

        default:
            json_out(['status' => 'error', 'message' => 'Action not supported.'], 400);
    }
} catch (Exception $e) {
    json_out(['status' => 'error', 'message' => $e->getMessage()], 400);
}